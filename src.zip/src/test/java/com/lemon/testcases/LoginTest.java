package com.lemon.testcases;

import com.lemon.base.BaseTest;
import com.lemon.data.Environment;
import com.lemon.pojo.ExcelPojo;
import com.lemon.util.PhoneRandomUtil;
import io.restassured.response.Response;
import org.testng.annotations.*;


import java.util.List;

import static io.restassured.RestAssured.given;

/**
 * @author shkstart
 * @create 2021-06-13 18:28
 */
public class LoginTest extends BaseTest {
    @BeforeClass
    public void setup(){
        //生成一个没有被注册的手机号码
        String phone = PhoneRandomUtil.getUnregisterPhone();
        //保存到环境变量
        Environment.envData.put("phone", phone);
        //读取文件中的指定数据row；
        List<ExcelPojo> listDatas =  readSpecifyExcelData(2,0,1);
        //获取第一行数据
        ExcelPojo excelPojo = listDatas.get(0);
        //请求之前参数替换替换
         excelPojo = casesReplace(excelPojo);
        //读取文件中的第几行数据；作为请求参数
//        Response res = request(listDatas.get(0));
        Response res = request(excelPojo,"login");
        //提取注册后的手机号码，保存到环境变量中
//        extractToEnvironment(listDatas.get(0), res);
        extractToEnvironment(excelPojo, res);
    }

    /**
     * 断言
     * @param excelPojo
     */
    @Test(dataProvider = "getLoginDatas")
    public void testAssert(ExcelPojo excelPojo) {
        //替换用例
         excelPojo = casesReplace(excelPojo);
        //响应数据
        Response res = request(excelPojo,"login");
        //断言
        assertResponse(excelPojo,res );
        assertSQL(excelPojo);
    }

    /**
     * 从excel读取指定数据作为参数
     * @return
     */
    @DataProvider
    public  Object[] getLoginDatas(){
        List<ExcelPojo> listDatas = readSpecifyExcelData( 2, 1, 11);
        //返回一维数组
        return listDatas.toArray();
    }


    @AfterTest
    public void tearDown(){
    }
}

//优化前
//        Map requestHeaderMap =  JSON.parseObject(listDatas.get(0).getRequestHeader());
//                given().
//                        body(listDatas.get(0).getInputParams()).
//                        headers(requestHeaderMap).
//                when().
//                        post(listDatas.get(0).getUrl()).
//                then().
//                        log().all().extract();

//优化前
//        //网址
//        String url = excelPojo.getUrl();
//        //参数
//        String inputParams = excelPojo.getInputParams();
//        //请求头
//        String requestHeader = excelPojo.getRequestHeader();
//        //map
//        Map requestHeaderMap = (Map) JSON.parse(requestHeader);
//        //获取响应结果
//        String expected = excelPojo.getExpected();
//        //把响应结果转成map
//        Map <String,Object>expectedMap = (Map) JSON.parse(expected);
//        Response res =
//                given().
//                        body(inputParams).
//                        headers(requestHeaderMap).
//                        when().
//                        post(url).
//                        then().
//                        log().all().extract().response();